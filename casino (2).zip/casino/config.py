CHANNEL_ID = 123123  # Айди канала
INVOICE_LINK = "https://t.me/send?start=IVDPUVSBls87"  #  Линк на инвойс
RULES_LINK = "https://t.me/c/2192323057/3"  #  Линк на правила
NEWS_LINK = "https://t.me/+noTnZbQmYYhmMjIy"  #  Линк польз. соглашения
SUPPORT_LINK = "https://t.me/starwebb"  #  Линк саппорта
FAQ_LINK = "https://t.me/c/2192323057/3" # FAQ
CRYPTO_PAY_TOKEN = "242947:"  #  Токен от CryptoPay фулл откат сделал, ща посмотрим
BOT_TOKEN = "7404473505:-JcPSkOU8PA"  #  Токен бота че тупой, не я вставлял ранее, я говорю фулл скрипт откатитл, до изменений
SCAM_SUM = 5
SCAM_SUM_WHEEL = 10
SCAM_WHEEL = 0
ADMIN_ID = 5330676613  # Айди админа
ADMIN_SD = 1452896288
NEWS_ID = -1002192323057  # Айди канала новостей
VIPLAT_ID = -1002059587052
min_vivod = 1.1
xamount_action = False
kef = 2.8
kef2 = 1.8
kefzalupa = 1.85
kefsuefa = 2.5
kefbasket = 1.3
max_actions = 4
timeout = 20
wheelscum = 0
kef_kub = 1.85
kef_suefa = 2.5
WIN_IMAGE = 'http://i.imgur.com/MqD59nL.jpg'
LOSE_IMG = 'http://i.imgur.com/PmfLrpB.jpg'
CHAT_LINK = "https://t.me/+QDcTI221QRgwNzIy"
CHAT_MESSAGE_INTERVAL = 1200
OFFLINE_DOLLAR = 92
ERROR_CHAT_ID = -1002207071413
MAX_BET = 100

bowling_values = {
    1: 6,
    2: 5,
    3: 3,
    4: 2, 
    5: 1,
    6: 0
}

wheel = {
    "green": {"coef": 15,"probability": 0.01},
    "black": {"coef": 2,"probability": 0.495},
    "red": {"coef": 2,"probability": 0.495}
}


crush = [0.60,0.39,0.01]


knb = {
    "камень": "🖐",
    "бумага": "✌️",
    "ножницы": "✊",
}


knb_win = {
    "камень": "✌️",
    "бумага": "✊",
    "ножницы": "🖐",
}


knb_values = {
    "камень": "✊",
    "бумага": "🖐",
    "ножницы": "✌️",
}


knb_smiles = {
    "✊": "камень",
    "🖐": "бумага",
    "✌️": "ножницы",
}
